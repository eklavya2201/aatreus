﻿using System;
using System.Linq;

namespace SalesCopilot
{
    public class SilenceDetector
    {
        private const int SilenceThreshold = 500; // 🔧 CHANGE THIS if needed
        private const int SilenceFrames = 20;

        private int _silentCount = 0;

        public bool IsSilent(byte[] audio)
        {
            short[] samples = new short[audio.Length / 2];
            Buffer.BlockCopy(audio, 0, samples, 0, audio.Length);

            double avg = samples.Average(s => Math.Abs(s));

            if (avg < SilenceThreshold)
                _silentCount++;
            else
                _silentCount = 0;

            return _silentCount > SilenceFrames;
        }

        public void Reset() => _silentCount = 0;
    }
}
