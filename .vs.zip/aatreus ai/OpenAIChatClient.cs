﻿using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace SalesCopilot
{
    public class OpenAIChatClient
    {
        private static readonly HttpClient http = new HttpClient();

        public async Task<string> SendAsync(string apiKey, string userText)
        {
            http.DefaultRequestHeaders.Clear();
            http.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", apiKey);

            var body = new
            {
                model = "gpt-3.5-turbo",

                messages = new[]
                {
                    new { role = "system", content = "You are a helpful sales copilot." },
                    new { role = "user", content = userText }
                }
            };

            var res = await http.PostAsync(
                "https://api.openai.com/v1/chat/completions",
                new StringContent(
                    JsonSerializer.Serialize(body),
                    Encoding.UTF8,
                    "application/json")
            );

            var json = await res.Content.ReadAsStringAsync();

            using var doc = JsonDocument.Parse(json);

            // 🔒 SAFE PARSING (NO EXCEPTION)
            if (!doc.RootElement.TryGetProperty("choices", out var choices))
                return "❌ OpenAI error (no choices)";

            if (choices.GetArrayLength() == 0)
                return "❌ OpenAI returned empty response";

            var choice = choices[0];

            if (!choice.TryGetProperty("message", out var message))
                return "❌ OpenAI message missing";

            if (!message.TryGetProperty("content", out var content))
                return "❌ OpenAI content missing";

            return content.GetString();
        }
    }
}
