﻿using System.Linq;

namespace SalesCopilot
{
    public static class SalesIntentDetector
    {
        private static readonly string[] Objections =
        {
            "expensive", "not interested", "call later",
            "already have", "too costly", "no budget"
        };

        public static bool IsObjection(string text)
        {
            text = text.ToLower();
            return Objections.Any(o => text.Contains(o));
        }
    }
}
