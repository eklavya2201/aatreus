﻿using NAudio.Wave;
using System.Collections.Generic;
using System.IO;

namespace SalesCopilot
{
    public class SystemAudioCapture
    {
        private WasapiLoopbackCapture _capture;
        private List<byte> _buffer = new();
        private WaveFormat _format;

        public void Start()
        {
            _buffer.Clear();
            _capture = new WasapiLoopbackCapture();
            _format = _capture.WaveFormat;

            _capture.DataAvailable += (s, e) =>
            {
                if (e.BytesRecorded > 0)
                    _buffer.AddRange(e.Buffer[..e.BytesRecorded]);
            };

            _capture.StartRecording();
        }

        public byte[] StopAndGetWav()
        {
            _capture.StopRecording();
            _capture.Dispose();

            // 🔴 Minimum 1.5 sec audio
            if (_buffer.Count < _format.AverageBytesPerSecond * 1.5)
                return null;

            using var ms = new MemoryStream();
            using var writer = new WaveFileWriter(ms, _format);
            writer.Write(_buffer.ToArray(), 0, _buffer.Count);
            writer.Flush();

            return ms.ToArray();
        }
    }
}
