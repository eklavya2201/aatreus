﻿using Newtonsoft.Json;
using System;
using System.Net.WebSockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SalesCopilot
{
    public class OpenAIRealtimeClient
    {
        private ClientWebSocket _ws;

        public event Action<string> OnTextResponse;

        public async Task ConnectAsync(string apiKey)
        {
            _ws = new ClientWebSocket();
            _ws.Options.SetRequestHeader("Authorization", $"Bearer {apiKey}");
            _ws.Options.SetRequestHeader("OpenAI-Beta", "realtime=v1");

            await _ws.ConnectAsync(
                new Uri("wss://api.openai.com/v1/realtime?model=gpt-4o-realtime-preview"),
                CancellationToken.None
            );

            _ = ReceiveLoop();
        }

        public async Task SendAudioAsync(byte[] pcm16)
        {
            string base64 = Convert.ToBase64String(pcm16);

            var payload = new
            {
                type = "input_audio_buffer.append",
                audio = base64
            };

            var json = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(payload));
            await _ws.SendAsync(json, WebSocketMessageType.Text, true, CancellationToken.None);
        }

        private async Task ReceiveLoop()
        {
            var buffer = new byte[8192];

            while (_ws.State == WebSocketState.Open)
            {
                var result = await _ws.ReceiveAsync(buffer, CancellationToken.None);
                var msg = Encoding.UTF8.GetString(buffer, 0, result.Count);

                if (msg.Contains("response.text.delta"))
                {
                    dynamic json = JsonConvert.DeserializeObject(msg);
                    string text = json.delta;
                    OnTextResponse?.Invoke(text);
                }
            }
        }
    }
}
